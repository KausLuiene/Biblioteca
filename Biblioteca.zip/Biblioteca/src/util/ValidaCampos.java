/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author usuario
 */
public class ValidaCampos {

    public static boolean validaNome(String nome) {
        return nome.matches("\\p{Upper}[\\p{IsLAtin}[ ]]+");
    }

    public static boolean validaLogin(String login) {
        return login.matches("\\p{Lower}[\\p{IsLAtin}[ ]]+");
    }
}
