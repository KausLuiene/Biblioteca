/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author usuario
 */
public class ConnectionFactory {

    public static Connection con;

    public static Connection getConnection() {
        try {
            String banco = "biblioteca";
            /* Nome do banco */
            String usuario = "root";
            /* Usuário de acesso ao banco */
            String senha = "teste001";
            /* Senha de acesso ao banco */
            con = DriverManager.getConnection("jdbc:mysql://localhost/" + banco, usuario, senha);
            return con;
        } catch (SQLException e) {
            System.out.println("Erro número: " + e.getErrorCode()
                    + " - Mensagem: " + e.getMessage());
            return null;
        }
    }
}
