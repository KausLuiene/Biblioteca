/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tableModel;

import Modelo.Usuario;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author usuario
 */
public class UsuarioTableModel extends AbstractTableModel {

    private List<Usuario> usuarios;

    public UsuarioTableModel() {
        this.usuarios = new ArrayList<Usuario>();
    }

    public UsuarioTableModel(List<Usuario> lista) {
        this();
        usuarios.addAll(lista);
    }

    @Override
    public int getRowCount() {
        return usuarios.size();
    }

    @Override
    public int getColumnCount() {
        return 2;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Usuario usuario = usuarios.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return usuario.getNome();
            case 1:
                return usuario.getLogin();
        }
        return "";
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Nome";
            case 1:
                return "Login";
            default:
                return "";
        }
    }

    public Usuario getusuario(int pos) {
        if (pos >= usuarios.size()) {
            return null;
        }
        return usuarios.get(pos);
    }
}
