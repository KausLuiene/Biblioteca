/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tableModel;

import Modelo.Emprestimo;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author emprestimo
 */
public class EmprestimoTableModel extends AbstractTableModel {

    private List<Emprestimo> emprestimos;

    public EmprestimoTableModel() {
        this.emprestimos = new ArrayList<Emprestimo>();
    }

    public EmprestimoTableModel(List<Emprestimo> lista) {
        this();
        emprestimos.addAll(lista);
    }

    @Override
    public int getRowCount() {
        return emprestimos.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Emprestimo emprestimo = emprestimos.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return emprestimo.getSituacaoDescricao();
            case 1:
                return emprestimo.getExemplar().getLivro();
            case 2:
                return emprestimo.getDataRetirada();
            case 3:
                return emprestimo.getDataEntrega();
        }
        return "";
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Situacao";
            case 1:
                return "Livro";
            case 2:
                return "Retirada";
            case 3:
                return "Devolução";
            default:
                return "";
        }
    }

    public Emprestimo getEmprestimo(int pos) {
        if (pos >= emprestimos.size()) {
            return null;
        }
        return emprestimos.get(pos);
    }
}
