/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tableModel;

import Modelo.Exemplar;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author exemplar
 */
public class ExemplarTableModel extends AbstractTableModel {

    private List<Exemplar> exemplares;

    public ExemplarTableModel() {
        this.exemplares = new ArrayList<Exemplar>();
    }

    public ExemplarTableModel(List<Exemplar> lista) {
        this();
        exemplares.addAll(lista);
    }

    @Override
    public int getRowCount() {
        return exemplares.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Exemplar exemplar = exemplares.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return exemplar.getOrdem();
            case 1:
                return exemplar.getLivro().getNome();
            case 2:
                return exemplar.getLivro().getEditora();
            case 3:
                return exemplar.getLivro().getEdicao();
        }
        return "";
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Ordem";
            case 1:
                return "Nome";
            case 2:
                return "Editora";
            case 3:
                return "Edicao";
            default:
                return "";
        }
    }

    public Exemplar getExemplar(int pos) {
        if (pos >= exemplares.size()) {
            return null;
        }
        return exemplares.get(pos);
    }
}
