/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tableModel;

import Modelo.Livro;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author livro
 */
public class LivroTableModel extends AbstractTableModel {

    private List<Livro> livros;

    public LivroTableModel() {
        this.livros = new ArrayList<Livro>();
    }

    public LivroTableModel(List<Livro> lista) {
        this();
        livros.addAll(lista);
    }

    @Override
    public int getRowCount() {
        return livros.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Livro livro = livros.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return livro.getNome();
            case 1:
                return livro.getEditora();
            case 2:
                return livro.getAutores();
            case 3:
                return livro.getAno();
            case 4:
                return livro.getEdicao();
        }
        return "";
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Nome";
            case 1:
                return "Editora";
            case 2:
                return "Autores";
            case 3:
                return "Ano";
            case 4:
                return "Edicao";
            default:
                return "";
        }
    }

    public Livro getlivro(int pos) {
        if (pos >= livros.size()) {
            return null;
        }
        return livros.get(pos);
    }
}
