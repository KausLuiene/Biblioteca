/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author usuario
 */
public class Emprestimo implements Serializable {

    private Integer id;
    private String situacao;
    private Date dataRetirada;
    private Date dataEntrega;
    private Exemplar exemplar;
    private Usuario usuario;

    final static public String NOVO_EMPRESTIMO = "E";
    final static public String PENDENTE = "P";
    final static public String DEVOLVIDO = "D";
    final static public String RENOVADO = "R";

    public Emprestimo() {
    }

    public Emprestimo(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSituacao() {
        return situacao;
    }

    public String getSituacaoDescricao() {
        switch (this.getSituacao()) {
            case NOVO_EMPRESTIMO:
                return "Empréstimo";

            case PENDENTE:
                return "Pendente";

            case DEVOLVIDO:
                return "Devolvido";

            case RENOVADO:
                return "Renovado";

        }
        return "";
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    public Date getDataRetirada() {
        return dataRetirada;
    }

    public void setDataRetirada(Date dataRetirada) {
        this.dataRetirada = dataRetirada;
    }

    public Date getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(Date dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public Exemplar getExemplar() {
        return exemplar;
    }

    public void setExemplar(Exemplar exemplar) {
        this.exemplar = exemplar;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
}
