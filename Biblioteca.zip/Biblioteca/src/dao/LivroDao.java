/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import Modelo.Livro;
import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author livro
 */
public class LivroDao {

    private Connection con;

    public LivroDao() {
        con = (Connection) ConnectionFactory.getConnection();
    }

    public int inserir(Livro livro) {
        PreparedStatement pstmt = null;
        try {
            con.setAutoCommit(false);
            String sqlInsertLivro = "INSERT INTO livro (nome, editora, autores, ano, edicao) VALUES (?,?,?,?,?)";
            pstmt = con.prepareStatement(sqlInsertLivro);
            pstmt.setString(1, livro.getNome());
            pstmt.setString(2, livro.getEditora());
            pstmt.setString(3, livro.getAutores());
            pstmt.setInt(4, livro.getAno());
            pstmt.setInt(5, livro.getEdicao());
            pstmt.execute();
            con.commit();
            return -1;
        } catch (SQLException e) {
            try {
                con.rollback();
                System.out.println(e.getMessage());
                return e.getErrorCode();
            } catch (SQLException ex) {
                System.out.println(e.getMessage());
                return ex.getErrorCode();
            }
        } finally {
            try {
                pstmt.close();
                con.setAutoCommit(true);
                con.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
                return e.getErrorCode();
            }
        }
    }

    public int alterar(Livro livro) {
        PreparedStatement pstmt = null;
        try {
            con.setAutoCommit(false);
            String sqlUpdateLivro = "UPDATE livro SET nome=?, editora=?, autores=?, ano=?, edicao=? WHERE id=?";
            pstmt = con.prepareStatement(sqlUpdateLivro);
            pstmt.setString(1, livro.getNome());
            pstmt.setString(2, livro.getEditora());
            pstmt.setString(3, livro.getAutores());
            pstmt.setInt(4, livro.getAno());
            pstmt.setInt(5, livro.getEdicao());
            pstmt.setInt(6, livro.getId());
            pstmt.execute();
            con.commit();
            return -1;
        } catch (SQLException e) {
            try {
                con.rollback();
                return e.getErrorCode();
            } catch (SQLException ex) {
                return ex.getErrorCode();
            }
        } finally {
            try {
                pstmt.close();
                con.setAutoCommit(true);
                con.close();
            } catch (SQLException e) {
                return e.getErrorCode();
            }
        }
    }

    public int excluir(Livro livro) {
        PreparedStatement pstmt = null;
        try {
            con.setAutoCommit(false);
            String sqlDeleteLivro = "DELETE FROM livro WHERE id=?";
            pstmt = con.prepareStatement(sqlDeleteLivro);
            pstmt.setInt(1, livro.getId());
            pstmt.execute();
            con.commit();
            return -1;
        } catch (SQLException e) {
            try {
                con.rollback();
                return e.getErrorCode();
            } catch (SQLException ex) {
                return ex.getErrorCode();
            }
        } finally {
            try {
                pstmt.close();
                con.setAutoCommit(true);
                con.close();
            } catch (SQLException e) {
                return e.getErrorCode();
            }
        }
    }

    public List<Livro> getLista() {
        try {
            List<Livro> listaLivros = new ArrayList<>();
            String sqlSelectLivros = "SELECT * FROM livro l ORDER BY l.nome ASC";
            PreparedStatement pstmt = con.prepareStatement(sqlSelectLivros);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Livro livro = new Livro();
                livro.setId(rs.getInt("id"));
                livro.setNome(rs.getString("nome"));
                livro.setEditora(rs.getString("editora"));
                livro.setAutores(rs.getString("autores"));
                livro.setAno(rs.getInt("ano"));
                livro.setEdicao(rs.getInt("edicao"));
                listaLivros.add(livro);
            }
            rs.close();
            pstmt.close();
            return listaLivros;
        } catch (SQLException e) {
            System.out.println("Erro número: " + e.getErrorCode()
                    + " - Mensagem: " + e.getMessage());
            return null;
        }
    }

    public Livro getLivroId(int id) {
        try {
            Livro livro = null;
            String sqlSelectLivroId = "SELECT * FROM livro l WHERE l.id = ?";
            PreparedStatement pstmt = con.prepareStatement(sqlSelectLivroId);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                livro.setId(rs.getInt("id"));
                livro.setNome(rs.getString("nome"));
                livro.setEditora(rs.getString("editora"));
                livro.setAutores(rs.getString("autores"));
                livro.setAno(rs.getInt("ano"));
                livro.setEdicao(rs.getInt("edicao"));
            }
            rs.close();
            pstmt.close();
            return livro;
        } catch (SQLException e) {
            System.out.println("Erro número: " + e.getErrorCode()
                    + " - Mensagem: " + e.getMessage());
            return null;
        }
    }

    public int getNumeroLivros() {
        try {
            String sqlSelectNumeroLivros = "SELECT COUNT(id) AS numLivros FROM livro";
            PreparedStatement pstmt = con.prepareStatement(sqlSelectNumeroLivros);
            ResultSet rs = pstmt.executeQuery();
            int numLivros = 0;
            while (rs.next()) {
                numLivros = rs.getInt("numLivros");
            }
            rs.close();
            pstmt.close();
            return numLivros;
        } catch (SQLException e) {
            System.out.println("Erro número: " + e.getErrorCode()
                    + " - Mensagem: " + e.getMessage());
            return -1;
        }
    }
}
