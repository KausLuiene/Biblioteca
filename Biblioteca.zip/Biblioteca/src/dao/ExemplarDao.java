/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import Modelo.Exemplar;
import Modelo.Livro;
import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author exemplar
 */
public class ExemplarDao {

    private Connection con;

    public ExemplarDao() {
        con = (Connection) ConnectionFactory.getConnection();
    }

    public int inserir(Exemplar exemplar) {
        PreparedStatement pstmt = null;
        try {
            con.setAutoCommit(false);
            String sqlInsertExemplar = "INSERT INTO exemplar (ordem, id_livro) VALUES (?,?)";
            pstmt = con.prepareStatement(sqlInsertExemplar);
            pstmt.setInt(1, exemplar.getOrdem());
            pstmt.setInt(2, exemplar.getLivro().getId());
            pstmt.execute();
            con.commit();
            return -1;
        } catch (SQLException e) {
            try {
                con.rollback();
                System.out.println(e.getMessage());
                return e.getErrorCode();
            } catch (SQLException ex) {
                System.out.println(e.getMessage());
                return ex.getErrorCode();
            }
        } finally {
            try {
                pstmt.close();
                con.setAutoCommit(true);
                con.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
                return e.getErrorCode();
            }
        }
    }

    public int alterar(Exemplar exemplar) {
        PreparedStatement pstmt = null;
        try {
            con.setAutoCommit(false);
            String sqlUpdateExemplar = "UPDATE exemplar SET ordem=?, id_livro=? WHERE id=?";
            pstmt = con.prepareStatement(sqlUpdateExemplar);
            pstmt.setInt(1, exemplar.getOrdem());
            pstmt.setInt(2, exemplar.getLivro().getId());
            pstmt.setInt(3, exemplar.getId());
            pstmt.execute();
            con.commit();
            return -1;
        } catch (SQLException e) {
            try {
                con.rollback();
                return e.getErrorCode();
            } catch (SQLException ex) {
                return ex.getErrorCode();
            }
        } finally {
            try {
                pstmt.close();
                con.setAutoCommit(true);
                con.close();
            } catch (SQLException e) {
                return e.getErrorCode();
            }
        }
    }

    public int excluir(Exemplar exemplar) {
        PreparedStatement pstmt = null;
        try {
            con.setAutoCommit(false);
            String sqlDeleteExemplar = "DELETE FROM exemplar WHERE id=?";
            pstmt = con.prepareStatement(sqlDeleteExemplar);
            pstmt.setInt(1, exemplar.getId());
            pstmt.execute();
            con.commit();
            return -1;
        } catch (SQLException e) {
            try {
                con.rollback();
                return e.getErrorCode();
            } catch (SQLException ex) {
                return ex.getErrorCode();
            }
        } finally {
            try {
                pstmt.close();
                con.setAutoCommit(true);
                con.close();
            } catch (SQLException e) {
                return e.getErrorCode();
            }
        }
    }

    public List<Exemplar> getLista() {
        try {
            List<Exemplar> listaExemplares = new ArrayList<>();
            String sqlSelectExemplares = "select e.*, l.id, l.nome, l.editora, "
                    + "l.edicao from exemplar e left join livro l"
                    + " on l.id = e.id_livro ORDER BY e.id ASC";
            PreparedStatement pstmt = con.prepareStatement(sqlSelectExemplares);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Exemplar exemplar = new Exemplar();
                exemplar.setId(rs.getInt("id"));                
                exemplar.setOrdem(rs.getInt("ordem"));
                Livro livro = new Livro();
                livro.setId(rs.getInt("id_livro"));
                livro.setNome(rs.getString("nome"));
                livro.setEditora(rs.getString("editora"));
                livro.setEdicao(rs.getInt("edicao"));
                exemplar.setLivro(livro);
                listaExemplares.add(exemplar);
            }
            rs.close();
            pstmt.close();
            return listaExemplares;
        } catch (SQLException e) {
            System.out.println("Erro número: " + e.getErrorCode()
                    + " - Mensagem: " + e.getMessage());
            return null;
        }
    }

    public Exemplar getExemplarId(int id) {
        try {
            Exemplar exemplar = null;
            String sqlSelectExemplarId = "select e.*, l.id, l.nome, l.editora, "
                    + "l.edicao from exemplar e left join livro l"
                    + " on l.id = e.id_livro where e.id=?";
            PreparedStatement pstmt = con.prepareStatement(sqlSelectExemplarId);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                exemplar = new Exemplar();
                exemplar.setId(rs.getInt("id"));
                exemplar.setOrdem(rs.getInt("ordem"));
                Livro livro = new Livro();
                livro.setId(rs.getInt("id_livro"));
                livro.setNome(rs.getString("nome"));
                livro.setEditora(rs.getString("editora"));
                livro.setEdicao(rs.getInt("edicao"));
                exemplar.setLivro(livro);
            }
            rs.close();
            pstmt.close();
            return exemplar;
        } catch (SQLException e) {
            System.out.println("Erro número: " + e.getErrorCode()
                    + " - Mensagem: " + e.getMessage());
            return null;
        }
    }

    public int getNumeroExemplares() {
        try {
            String sqlSelectNumeroExemplares = "SELECT COUNT(id) AS numExemplares FROM exemplar";
            PreparedStatement pstmt = con.prepareStatement(sqlSelectNumeroExemplares);
            ResultSet rs = pstmt.executeQuery();
            int numExemplares = 0;
            while (rs.next()) {
                numExemplares = rs.getInt("numExemplares");
            }
            rs.close();
            pstmt.close();
            return numExemplares;
        } catch (SQLException e) {
            System.out.println("Erro número: " + e.getErrorCode()
                    + " - Mensagem: " + e.getMessage());
            return -1;
        }
    }
}
