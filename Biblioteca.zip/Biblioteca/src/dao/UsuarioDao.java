/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import Modelo.Usuario;
import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author usuario
 */
public class UsuarioDao {

    private Connection con;

    public UsuarioDao() {
        con = (Connection) ConnectionFactory.getConnection();
    }

    public int inserir(Usuario usuario) {
        PreparedStatement pstmt = null;
        try {
            con.setAutoCommit(false);
            String sqlInsertUsuario = "INSERT INTO usuario (nome, login) VALUES (?,?)";
            pstmt = con.prepareStatement(sqlInsertUsuario);
            pstmt.setString(1, usuario.getNome());
            pstmt.setString(2, usuario.getLogin());
            pstmt.execute();
            con.commit();
            return -1;
        } catch (SQLException e) {
            try {
                con.rollback();
                System.out.println(e.getMessage());
                return e.getErrorCode();
            } catch (SQLException ex) {
                System.out.println(e.getMessage());
                return ex.getErrorCode();
            }
        } finally {
            try {
                pstmt.close();
                con.setAutoCommit(true);
                con.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
                return e.getErrorCode();
            }
        }
    }

    public int alterar(Usuario usuario) {
        PreparedStatement pstmt = null;
        try {
            con.setAutoCommit(false);
            String sqlUpdateUsuario = "UPDATE usuario SET nome=?, login=? WHERE id=?";
            pstmt = con.prepareStatement(sqlUpdateUsuario);
            pstmt.setString(1, usuario.getNome());
            pstmt.setString(2, usuario.getLogin());
            pstmt.setInt(3, usuario.getId());
            pstmt.execute();
            con.commit();
            return -1;
        } catch (SQLException e) {
            try {
                con.rollback();
                return e.getErrorCode();
            } catch (SQLException ex) {
                return ex.getErrorCode();
            }
        } finally {
            try {
                pstmt.close();
                con.setAutoCommit(true);
                con.close();
            } catch (SQLException e) {
                return e.getErrorCode();
            }
        }
    }

    public int excluir(Usuario usuario) {
        PreparedStatement pstmt = null;
        try {
            con.setAutoCommit(false);
            String sqlDeleteUsuario = "DELETE FROM usuario WHERE id=?";
            pstmt = con.prepareStatement(sqlDeleteUsuario);
            pstmt.setInt(1, usuario.getId());
            pstmt.execute();
            con.commit();
            return -1;
        } catch (SQLException e) {
            try {
                con.rollback();
                return e.getErrorCode();
            } catch (SQLException ex) {
                return ex.getErrorCode();
            }
        } finally {
            try {
                pstmt.close();
                con.setAutoCommit(true);
                con.close();
            } catch (SQLException e) {
                return e.getErrorCode();
            }
        }
    }

    public List<Usuario> getLista() {
        try {
            List<Usuario> listaUsuarios = new ArrayList<>();
            String sqlSelectUsuarios = "SELECT * FROM usuario u ORDER BY u.nome ASC";
            PreparedStatement pstmt = con.prepareStatement(sqlSelectUsuarios);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setId(rs.getInt("id"));
                usuario.setNome(rs.getString("nome"));
                usuario.setLogin(rs.getString("login"));
                listaUsuarios.add(usuario);
            }
            rs.close();
            pstmt.close();
            return listaUsuarios;
        } catch (SQLException e) {
            System.out.println("Erro número: " + e.getErrorCode()
                    + " - Mensagem: " + e.getMessage());
            return null;
        }
    }

    public Usuario getUsuarioId(int id) {
        try {
            Usuario usuario = null;
            String sqlSelectUsuarioId = "SELECT * FROM usuario u WHERE u.id = ?";
            PreparedStatement pstmt = con.prepareStatement(sqlSelectUsuarioId);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                usuario = new Usuario();
                usuario.setId(rs.getInt("idUsuario"));
                usuario.setNome(rs.getString("nome"));
                usuario.setLogin(rs.getString("login"));
            }
            rs.close();
            pstmt.close();
            return usuario;
        } catch (SQLException e) {
            System.out.println("Erro número: " + e.getErrorCode()
                    + " - Mensagem: " + e.getMessage());
            return null;
        }
    }

    public int getNumeroUsuarios() {
        try {
            String sqlSelectNumeroUsuarios = "SELECT COUNT(id) AS numUsuarios FROM usuario";
            PreparedStatement pstmt = con.prepareStatement(sqlSelectNumeroUsuarios);
            ResultSet rs = pstmt.executeQuery();
            int numUsuarios = 0;
            while (rs.next()) {
                numUsuarios = rs.getInt("numUsuarios");
            }
            rs.close();
            pstmt.close();
            return numUsuarios;
        } catch (SQLException e) {
            System.out.println("Erro número: " + e.getErrorCode()
                    + " - Mensagem: " + e.getMessage());
            return -1;
        }
    }
}
