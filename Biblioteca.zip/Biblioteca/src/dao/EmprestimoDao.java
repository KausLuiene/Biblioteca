/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import Modelo.Emprestimo;
import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author emprestimo
 */
public class EmprestimoDao {

    private Connection con;

    public EmprestimoDao() {
        con = (Connection) ConnectionFactory.getConnection();
    }

    public int inserir(Emprestimo emprestimo) {
        PreparedStatement pstmt = null;
        try {
            con.setAutoCommit(false);
            String sqlInsertEmprestimo = "INSERT INTO emprestimo (situacao, data_retirada, id_livro, id_usuario) VALUES (?,?,?,?)";
            pstmt = con.prepareStatement(sqlInsertEmprestimo);
            pstmt.setString(1, Emprestimo.NOVO_EMPRESTIMO);
            pstmt.setDate(2, new java.sql.Date(emprestimo.getDataRetirada().getTime()));
            pstmt.setInt(3, emprestimo.getExemplar().getId());
            pstmt.setInt(4, emprestimo.getUsuario().getId());
            pstmt.execute();
            con.commit();
            return -1;
        } catch (SQLException e) {
            try {
                con.rollback();
                System.out.println(e.getMessage());
                return e.getErrorCode();
            } catch (SQLException ex) {
                System.out.println(e.getMessage());
                return ex.getErrorCode();
            }
        } finally {
            try {
                pstmt.close();
                con.setAutoCommit(true);
                con.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
                return e.getErrorCode();
            }
        }
    }

    public int alterar(Emprestimo emprestimo) {
        PreparedStatement pstmt = null;
        try {
            con.setAutoCommit(false);
            String sqlUpdateEmprestimo = "UPDATE emprestimo SET situacao=?, data_entrega=? WHERE id=?";
            pstmt = con.prepareStatement(sqlUpdateEmprestimo);
            pstmt.setString(1, emprestimo.getSituacao());
            pstmt.setDate(2, new java.sql.Date(emprestimo.getDataEntrega().getTime()));
            pstmt.setInt(3, emprestimo.getId());
            pstmt.execute();
            con.commit();
            return -1;
        } catch (SQLException e) {
            try {
                con.rollback();
                return e.getErrorCode();
            } catch (SQLException ex) {
                return ex.getErrorCode();
            }
        } finally {
            try {
                pstmt.close();
                con.setAutoCommit(true);
                con.close();
            } catch (SQLException e) {
                return e.getErrorCode();
            }
        }
    }

    public List<Emprestimo> getLista() {
        try {
            ExemplarDao exemplarDao;
            UsuarioDao usuarioDao;
            List<Emprestimo> listaEmprestimos = new ArrayList<>();
            String sqlSelectEmprestimos = "SELECT * FROM emprestimo e ORDER BY e.id ASC";
            PreparedStatement pstmt = con.prepareStatement(sqlSelectEmprestimos);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                usuarioDao = new UsuarioDao();
                exemplarDao = new ExemplarDao();
                Emprestimo emprestimo = new Emprestimo();
                emprestimo.setId(rs.getInt("id"));
                emprestimo.setDataEntrega(rs.getDate("data_entrega"));
                emprestimo.setDataRetirada(rs.getDate("data_retirada"));
                emprestimo.setUsuario(usuarioDao.getUsuarioId(rs.getInt("id_usuario")));
                emprestimo.setExemplar(exemplarDao.getExemplarId(rs.getInt("id_livro")));
                listaEmprestimos.add(emprestimo);
            }
            rs.close();
            pstmt.close();
            return listaEmprestimos;
        } catch (SQLException e) {
            System.out.println("Erro número: " + e.getErrorCode()
                    + " - Mensagem: " + e.getMessage());
            return null;
        }
    }

    public Emprestimo getEmprestimoId(int id) {
        try {
            ExemplarDao exemplarDao;
            UsuarioDao usuarioDao;
            Emprestimo emprestimo = null;
            String sqlSelectEmprestimoId = "SELECT * FROM emprestimo e WHERE e.id = ?";
            PreparedStatement pstmt = con.prepareStatement(sqlSelectEmprestimoId);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                usuarioDao = new UsuarioDao();
                exemplarDao = new ExemplarDao();
                emprestimo.setId(rs.getInt("id"));
                emprestimo.setDataEntrega(rs.getDate("data_entrega"));
                emprestimo.setDataRetirada(rs.getDate("data_retirada"));
                emprestimo.setUsuario(usuarioDao.getUsuarioId(rs.getInt("id_usuario")));
                emprestimo.setExemplar(exemplarDao.getExemplarId(rs.getInt("id_livro")));
            }
            rs.close();
            pstmt.close();
            return emprestimo;
        } catch (SQLException e) {
            System.out.println("Erro número: " + e.getErrorCode()
                    + " - Mensagem: " + e.getMessage());
            return null;
        }
    }

    public int getNumeroEmprestimos() {
        try {
            String sqlSelectNumeroEmprestimos = "SELECT COUNT(id) AS numEmprestimos FROM emprestimo";
            PreparedStatement pstmt = con.prepareStatement(sqlSelectNumeroEmprestimos);
            ResultSet rs = pstmt.executeQuery();
            int numEmprestimos = 0;
            while (rs.next()) {
                numEmprestimos = rs.getInt("numEmprestimos");
            }
            rs.close();
            pstmt.close();
            return numEmprestimos;
        } catch (SQLException e) {
            System.out.println("Erro número: " + e.getErrorCode()
                    + " - Mensagem: " + e.getMessage());
            return -1;
        }
    }
}
