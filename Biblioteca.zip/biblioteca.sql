-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema biblioteca
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `biblioteca` ;

-- -----------------------------------------------------
-- Schema biblioteca
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `biblioteca` DEFAULT CHARACTER SET utf8 ;
USE `biblioteca` ;

-- -----------------------------------------------------
-- Table `biblioteca`.`livro`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `biblioteca`.`livro` ;

CREATE TABLE IF NOT EXISTS `biblioteca`.`livro` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `edicao` INT NULL,
  `nome` VARCHAR(255) NULL,
  `ano` INT(4) NULL,
  `editora` VARCHAR(255) NOT NULL,
  `autores` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `biblioteca`.`exemplar`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `biblioteca`.`exemplar` ;

CREATE TABLE IF NOT EXISTS `biblioteca`.`exemplar` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `ordem` INT NULL,
  `id_livro` INT NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_exemplar_livro1`
    FOREIGN KEY (`id_livro`)
    REFERENCES `biblioteca`.`livro` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `fk_exemplar_livro1_idx` ON `biblioteca`.`exemplar` (`id_livro` ASC);


-- -----------------------------------------------------
-- Table `biblioteca`.`usuario`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `biblioteca`.`usuario` ;

CREATE TABLE IF NOT EXISTS `biblioteca`.`usuario` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(100) NULL,
  `tipo` ENUM('A', 'P') NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `biblioteca`.`emprestimo`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `biblioteca`.`emprestimo` ;

CREATE TABLE IF NOT EXISTS `biblioteca`.`emprestimo` (
  `id` INT NOT NULL,
  `situacao` ENUM('E', 'P', 'R', 'D') NULL,
  `id_livro` INT NOT NULL,
  `id_usuario` INT NOT NULL,
  `data_retirada` DATE NULL,
  `data_entrega` DATE NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_emprestimo_livro1`
    FOREIGN KEY (`id_livro`)
    REFERENCES `biblioteca`.`livro` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_emprestimo_usuario1`
    FOREIGN KEY (`id_usuario`)
    REFERENCES `biblioteca`.`usuario` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `fk_emprestimo_livro1_idx` ON `biblioteca`.`emprestimo` (`id_livro` ASC);

CREATE INDEX `fk_emprestimo_usuario1_idx` ON `biblioteca`.`emprestimo` (`id_usuario` ASC);


-- -----------------------------------------------------
-- Table `biblioteca`.`multa`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `biblioteca`.`multa` ;

CREATE TABLE IF NOT EXISTS `biblioteca`.`multa` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `valor` INT NULL,
  `pago` ENUM('S', 'N') NULL,
  `id_emprestimo` INT NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_multa_emprestimo1`
    FOREIGN KEY (`id_emprestimo`)
    REFERENCES `biblioteca`.`emprestimo` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `fk_multa_emprestimo1_idx` ON `biblioteca`.`multa` (`id_emprestimo` ASC);


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
